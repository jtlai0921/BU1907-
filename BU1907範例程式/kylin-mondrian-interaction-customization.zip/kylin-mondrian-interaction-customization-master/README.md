# kylin-mondrian-interaction-customization
对 https://github.com/mustangore/kylin-mondrian-interaction 这个项目进行定制，比如支持Count Distinct，支持表关联的格式形式等等
