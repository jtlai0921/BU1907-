DROP TABLE IF EXISTS os.ao_sessions;
