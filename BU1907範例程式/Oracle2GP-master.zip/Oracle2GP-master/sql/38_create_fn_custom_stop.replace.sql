DROP FUNCTION IF EXISTS os.fn_customstop(text, integer, integer);
